using UnityEngine;
using UnityEngine.InputSystem;

public class SaltLumpController : MonoBehaviour
{
    private Rigidbody rb;
    private bool isHolding = false;
    private float currentHoldDistance = 0f;
    private Quaternion originalRotation;

    [Header("Speed Settings")]
    public float keyboardMoveSpeed = 8f;   

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        }

        // Lock in the salt's starting flat orientation angle
        originalRotation = Quaternion.Euler(0f, transform.eulerAngles.y, 0f);
    }

    void OnMouseDown()
    {
        if (Camera.main == null) return;

        isHolding = true;
        
        // Disable gravity and physics calculation matrices while dragging
        rb.useGravity = false;  
        rb.isKinematic = true;   
        rb.linearVelocity = Vector3.zero; 
        rb.angularVelocity = Vector3.zero;

        // Instantly force it flat and upright the millisecond you click it
        transform.rotation = originalRotation;

        currentHoldDistance = Vector3.Distance(Camera.main.transform.position, transform.position);
        
        // Safeguard boundary check to ensure it never vanishes behind the camera view layer
        if (currentHoldDistance < 1f || currentHoldDistance > 15f)
        {
            currentHoldDistance = 3.5f; 
        }
    }

    void OnMouseUp()
    {
        isHolding = false;
        rb.isKinematic = false;  
        rb.useGravity = true;    
    }

    void Update()
    {
        if (!isHolding || Keyboard.current == null || Mouse.current == null || Camera.main == null) return;

        // PRIMARY MOUSE POSITION DRAGGING
        Vector2 mouseScreenPos = Mouse.current.position.ReadValue();
        Vector3 mousePos = new Vector3(mouseScreenPos.x, mouseScreenPos.y, currentHoldDistance);
        Vector3 targetWorldPos = Camera.main.ScreenToWorldPoint(mousePos);
        transform.position = targetWorldPos;

        // ADDITIONAL ACCELERATION (ARROW KEYS)
        Vector3 arrowMovement = Vector3.zero;
        if (Keyboard.current.upArrowKey.isPressed)    arrowMovement += Vector3.forward;
        if (Keyboard.current.downArrowKey.isPressed)  arrowMovement += Vector3.back;
        if (Keyboard.current.leftArrowKey.isPressed)  arrowMovement += Vector3.left;
        if (Keyboard.current.rightArrowKey.isPressed) arrowMovement += Vector3.right;
        
        currentHoldDistance += arrowMovement.z * keyboardMoveSpeed * Time.deltaTime;
        transform.position += arrowMovement * keyboardMoveSpeed * Time.deltaTime;

        // STRICT LAYOUT OVERRIDE: Force it to stay perfectly level and upright every frame
        transform.rotation = originalRotation;
    }
}
