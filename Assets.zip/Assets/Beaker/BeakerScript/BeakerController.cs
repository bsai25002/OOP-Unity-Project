using UnityEngine;
using UnityEngine.InputSystem;

public class BeakerController : MonoBehaviour
{
    private Rigidbody rb;
    private bool isHolding = false;
    private float tiltAngle = 0f; // Manages the Pouring (X-Axis)
    private float yawAngle = 0f;  // Manages the Spinning (Y-Axis)
    private float currentHoldDistance = 0f;

    [Header("Speed Settings")]
    public float keyboardMoveSpeed = 8f;   
    public float rotateSpeed = 100f;       
    public float tiltSpeed = 80f;          

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        }

        yawAngle = transform.eulerAngles.y;
        tiltAngle = transform.eulerAngles.x;
    }

    void OnMouseDown()
    {
        if (Camera.main == null) return;

        isHolding = true;
        rb.useGravity = false;  
        rb.isKinematic = true;   
        rb.linearVelocity = Vector3.zero; 
        rb.angularVelocity = Vector3.zero;

        // =======================================================
        // RESET TILT ANGLE INSTANTLY ON RE-PICK
        // =======================================================
        tiltAngle = 0f; 
        // Grab the current spin direction so it stays facing the same way horizontally
        yawAngle = transform.eulerAngles.y; 
        transform.rotation = Quaternion.Euler(0f, yawAngle, 0f);

        currentHoldDistance = Vector3.Distance(Camera.main.transform.position, transform.position);
    }

    void OnMouseUp()
    {
        isHolding = false;
        rb.isKinematic = false;  
        rb.useGravity = true;    
    }

    void Update()
    {
        if (!isHolding || Keyboard.current == null || Mouse.current == null || Camera.main == null) return;

        // PRIMARY MOUSE POSITION DRAGGING
        Vector2 mouseScreenPos = Mouse.current.position.ReadValue();
        Vector3 mousePos = new Vector3(mouseScreenPos.x, mouseScreenPos.y, currentHoldDistance);
        Vector3 targetWorldPos = Camera.main.ScreenToWorldPoint(mousePos);
        transform.position = targetWorldPos;

        // ADDITIONAL ACCELERATION (ARROW KEYS)
        Vector3 arrowMovement = Vector3.zero;
        if (Keyboard.current.upArrowKey.isPressed)    arrowMovement += Vector3.forward;
        if (Keyboard.current.downArrowKey.isPressed)  arrowMovement += Vector3.back;
        if (Keyboard.current.leftArrowKey.isPressed)  arrowMovement += Vector3.left;
        if (Keyboard.current.rightArrowKey.isPressed) arrowMovement += Vector3.right;
        
        currentHoldDistance += arrowMovement.z * keyboardMoveSpeed * Time.deltaTime;
        transform.position += arrowMovement * keyboardMoveSpeed * Time.deltaTime;

        // HORIZONTAL SPINNING (A / D KEYS)
        if (Keyboard.current.aKey.isPressed) yawAngle += rotateSpeed * Time.deltaTime;
        if (Keyboard.current.dKey.isPressed) yawAngle -= rotateSpeed * Time.deltaTime;

        // PRECISE CORRECTED POURING (SCROLL WHEEL)
        Vector2 scrollDelta = Mouse.current.scroll.ReadValue();
        if (Mathf.Abs(scrollDelta.y) > 0.1f)
        {
            float scrollDirection = Mathf.Sign(scrollDelta.y); 
            tiltAngle += scrollDirection * tiltSpeed * Time.deltaTime;
        }

        // COMBINE AND APPLY SEPARATED AXES
        transform.rotation = Quaternion.Euler(tiltAngle, yawAngle, 0f);
    }
}
