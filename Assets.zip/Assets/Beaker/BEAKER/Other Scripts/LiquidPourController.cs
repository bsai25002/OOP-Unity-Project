using UnityEngine;

public class LiquidPourController : MonoBehaviour
{
    [Header("Pour Settings")]
    public float pourTiltThreshold = 30f;    
    public float fluidTransferSpeed = 0.25f; 
    
    [Header("Source Liquid Mesh Link")]
    public GameObject sourceLiquidMeshObject; 
    public float sourceMaxHeight = 0.005f;    // Set to your exact preferred flat thickness
    
    private float currentSourceWater = 1.0f; 
    private bool isEraseTriggered = false;

    private void Start()
    {
        // Keep the main physics body awake to support child trigger networks
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb != null) rb.WakeUp();
    }

    // This is called continuously by the child spout's physics trigger contact
    public void ExecutePourAndShrink(BeakerChemistryManager targetBeaker)
    {
        if (isEraseTriggered) return;

        // Verify the beaker body is actively tilted past the threshold limit
        float currentTilt = transform.localEulerAngles.x;
        if (currentTilt > 180) currentTilt -= 360f;

        if (Mathf.Abs(currentTilt) >= pourTiltThreshold && currentSourceWater > 0f)
        {
            // 1. Drain the source internal volume tracker
            currentSourceWater = Mathf.Max(currentSourceWater - fluidTransferSpeed * Time.deltaTime, 0f);
            
            // 2. Shrink the local height scale cleanly using your hardcoded width boundaries
            if (sourceLiquidMeshObject != null)
            {
                float calculatedHeight = currentSourceWater * sourceMaxHeight;
                sourceLiquidMeshObject.transform.localScale = new Vector3(0.04f, calculatedHeight, 0.04f);
            }

            // 3. Simultaneously fill the receiver beaker sitting downstairs
            if (targetBeaker != null)
            {
                targetBeaker.ReceiveLiquid(fluidTransferSpeed);
            }

            // 4. THE ABSOLUTE DEACTIVATION TRIGGER: Shut down the mesh the instant it goes dry
            if (currentSourceWater <= 0.01f)
            {
                currentSourceWater = 0f;
                isEraseTriggered = true;

                if (sourceLiquidMeshObject != null)
                {
                    sourceLiquidMeshObject.transform.localScale = new Vector3(0.04f, 0f, 0.04f);
                    sourceLiquidMeshObject.SetActive(false); // Hard GameObject shutdown
                }
                Debug.Log("Success: Source water shrunk completely and shut down!");
            }
        }
    }
}
