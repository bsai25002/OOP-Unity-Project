using UnityEngine;

public class BeakerInsideTrigger : MonoBehaviour
{
    private BeakerChemistryManager mainManager;

    void Start()
    {
        // Automatically hook into the parent container's chemical script
        mainManager = GetComponentInParent<BeakerChemistryManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        // Detects if a solid physical salt lump drops past the beaker lip
        if (other.CompareTag("SaltLump") || other.CompareTag("ChemicalGrain"))
        {
            if (mainManager != null)
            {
                mainManager.AddSaltFromLump();
            }

            // Vaporize the physical item mesh immediately so it disappears nicely inside the glass
            Destroy(other.gameObject);
        }
    }
}
