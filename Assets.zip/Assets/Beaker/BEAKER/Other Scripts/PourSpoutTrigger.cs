using UnityEngine;

public class PourSpoutTrigger : MonoBehaviour
{
    private LiquidPourController parentPourController;

    void Start()
    {
        // Fetch the master pour control logic from the parent beaker body upstairs
        parentPourController = GetComponentInParent<LiquidPourController>();
    }

    // Runs continuously while the spout collider sits inside the receiver's pad zone
    private void OnTriggerStay(Collider other)
    {
        // Detect if we are touching the PourDetectionPad zone on the receiver beaker
        if (other.CompareTag("PourPad"))
        {
            // Fetch the chemistry manager from the receiver beaker's parent tree
            BeakerChemistryManager receiverManager = other.GetComponentInParent<BeakerChemistryManager>();

            if (parentPourController != null && receiverManager != null)
            {
                // Inject the execution loop from the contact layer directly into the parent script
                parentPourController.ExecutePourAndShrink(receiverManager);
            }
        }
    }
}
