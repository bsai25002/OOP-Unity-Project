using UnityEngine;
using System.Collections.Generic;

public class PourPadSensor : MonoBehaviour
{
    private BeakerChemistryManager receiverManager;
    private List<LiquidPourController> activePourers = new List<LiquidPourController>();

    void Start()
    {
        // Finds the chemical manager component on the empty receiving beaker body
        receiverManager = GetComponentInParent<BeakerChemistryManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        // Tracks when the pour point spout touches our top pad plate
        if (other.CompareTag("PourSpout"))
        {
            LiquidPourController sourcePourer = other.GetComponentInParent<LiquidPourController>();
            if (sourcePourer != null && !activePourers.Contains(sourcePourer))
            {
                activePourers.Add(sourcePourer);
                Debug.Log("Physics Log: Spout connected to pouring pad!");
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("PourSpout"))
        {
            LiquidPourController sourcePourer = other.GetComponentInParent<LiquidPourController>();
            if (sourcePourer != null && activePourers.Contains(sourcePourer))
            {
                activePourers.Remove(sourcePourer);
                Debug.Log("Physics Log: Spout disconnected.");
            }
        }
    }

    void Update()
    {
        // Continuously process fluid transfer for any connected beakers
        foreach (LiquidPourController sourcePourer in activePourers)
        {
            if (sourcePourer != null && receiverManager != null)
            {
                // Call the synchronized direct-injection logic directly on the validated beaker!
                sourcePourer.ExecutePourAndShrink(receiverManager);
            }
        }
    }
}
