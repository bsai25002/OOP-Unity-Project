using UnityEngine;

public class BeakerChemistryManager : MonoBehaviour
{
    [Header("Liquid Visual Components")]
    public GameObject liquidMeshObject;   // Drag your 'ReceiverWater' CYLINDER here

    [Header("Chemistry States")]
    public bool hasSaltAdded = false;
    public float currentLiquidAmount = 0f; // 0 (empty) to 1 (full)
    public Renderer liquidRenderer;       // Drag 'ReceiverWater' mesh renderer here
    public Color resolvedNaOHColor = new Color(0.9f, 0.9f, 1f, 0.6f); 

    [Header("Shake Detection Settings")]
    public int requiredShakes = 10;
    public float shakeThresholdVelocity = 5f; 
    public float shakeCooldown = 0.3f;        

    private int currentShakeCount = 0;
    private Vector3 lastPosition;
    private float lastShakeTime;
    private bool isDissolvedComplete = false;

    void Start()
    {
        lastPosition = transform.position;
        
        // FOOLPROOF MICRO-SCALE FIX: Completely deactivate the object on frame one.
        // This makes the beaker look perfectly empty without touching scale math!
        if (liquidMeshObject != null)
        {
            liquidMeshObject.SetActive(false);
        }
    }

    public void ReceiveLiquid(float fillRate)
    {
        if (currentLiquidAmount < 1.0f)
        {
            currentLiquidAmount = Mathf.Min(currentLiquidAmount + fillRate * Time.deltaTime, 1.0f);
            
            // The exact frame water starts arriving, snap the fixed-size cylinder wide awake!
            if (liquidMeshObject != null && !liquidMeshObject.activeSelf)
            {
                liquidMeshObject.SetActive(true);
                // Hardcode lock the scale here just as a permanent shield against distortion
                liquidMeshObject.transform.localScale = new Vector3(0.04f, 0.005f, 0.04f);
            }
        }
    }

    void Update()
    {
        if (hasSaltAdded && currentLiquidAmount > 0.3f && !isDissolvedComplete)
        {
            DetectPhysicalShaking();
        }
    }

    public void AddSaltFromLump()
    {
        hasSaltAdded = true;
        Debug.Log("Chemistry Log: Salt added to beaker.");
    }

    void DetectPhysicalShaking()
    {
        float currentSpeed = Vector3.Distance(transform.position, lastPosition) / Time.deltaTime;
        lastPosition = transform.position;

        if (currentSpeed > shakeThresholdVelocity && Time.time - lastShakeTime > shakeCooldown)
        {
            currentShakeCount++;
            lastShakeTime = Time.time;
            if (currentShakeCount >= requiredShakes) TriggerChemicalReaction();
        }
    }

    void TriggerChemicalReaction()
    {
        isDissolvedComplete = true;
        if (liquidRenderer != null) liquidRenderer.material.color = resolvedNaOHColor;
    }
}
